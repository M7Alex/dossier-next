import { NextRequest, NextResponse } from 'next/server';

const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };

export async function OPTIONS() { return new NextResponse(null, { status: 204, headers: CORS }); }

export async function POST(req: NextRequest) {
  const body = await req.json();
  try {
    const url = `${process.env.KV_REST_API_URL}/set/dossier_content`;
    await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.KV_REST_API_TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(JSON.stringify({ ...body, savedAt: new Date().toISOString() })),
    });
    return NextResponse.json({ ok: true }, { headers: CORS });
  } catch { return NextResponse.json({ ok: false }, { status: 500, headers: CORS }); }
}

export async function GET() {
  try {
    const url = `${process.env.KV_REST_API_URL}/get/dossier_content`;
    const r = await fetch(url, { headers: { Authorization: `Bearer ${process.env.KV_REST_API_TOKEN}` } });
    const j = await r.json();
    if (!j.result) return NextResponse.json({ content: {}, extraPages: [] }, { headers: CORS });
    return NextResponse.json(JSON.parse(j.result), { headers: CORS });
  } catch { return NextResponse.json({ content: {}, extraPages: [] }, { headers: CORS }); }
}
